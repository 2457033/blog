var createError = require('http-errors')
var express = require('express')
var path = require('path')
var cookieParser = require('cookie-parser')
var logger = require('morgan')
// const { createServer } = require("http");

const db = require('./db/index')
const { utcNow, filterTime } = require('./utils/common')

var app = express()

// view engine setup
app.set('views', path.join(__dirname, 'views'))
app.set('view engine', 'jade')
app.set('trust proxy', true)

// 将uploads文件夹中的内容公开
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use(logger('dev'))
app.use(express.json())
app.use(express.urlencoded({ extended: false }))
app.use(cookieParser())
app.use(express.static(path.join(__dirname, 'public')))

app.all('*', function (req, res, next) {
  res.header('Access-Control-Allow-Origin', '*')
  res.header('Access-Control-Allow-Headers', '*')
  res.header('Access-Control-Allow-Methods', '*')
  next()
})

app.use(express.json())

const classify = require('./classify/classify')

// 身份验证
const tokenServer = require('./utils/token')
// app.use(tokenServer.verify)

// 全局中间件，获取分页参数并做容错处理
app.use(tokenServer.verify, async (req, res, next) => {
  // const pageSize = parseInt(req.query.pageSize)
  // const page = parseInt(req.query.page)
  // const pageOptions = {
  //   page: isNaN(page) ? 1 : page,
  //   pageSize: isNaN(pageSize) ? 1 : pageSize
  // }
  // req.pageOptions = pageOptions
  //////////////////////////////////////////
  const { url, headers } = req
  const userIp = req.ip || req.connection.remoteAddress
  const userAgent = headers['user-agent']
  const referrer = headers['referer']
  const userId = req.tokenPayload ? req.tokenPayload.id : null
  if (!referrer) {
    next()
    return
  }
  try {
    await db('insert into visit_logs (url, userIp, userAgent, referrer, userId, visitTime) values(?, ?, ?, ?, ?, ?)',
      [url, userIp, userAgent, referrer, userId, utcNow()]
    )
  } catch (err) {
    console.error('访问日志记录失败:', err);
  }
  next();
})

var indexRouter = require('./routes/index')
var menusRouter = require('./routes/menus')
var usersRouter = require('./routes/users')
var roleRouter = require('./routes/role')
var uploadRouter = require('./routes/upload')
var homeRouter = require('./routes/home')
app.use('/', indexRouter)
app.use('/api/menus', menusRouter)
app.use('/api/users', usersRouter)
app.use('/api/role', roleRouter)
app.use('/api/upload', uploadRouter)
app.use('/api/home', homeRouter)

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404))
})

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message
  res.locals.error = req.app.get('env') === 'development' ? err : {}
  // render the error page
  res.status(err.status || 500)
  res.render('error')
})

module.exports = app
