// module.exports = function (wss) {
//     const qs = require('querystring')
//     wss.on('connection', (ws, req) => {
//         console.log('连接成功');
//         ws.on('message',(id)=> {
//             console.log(id);
//         });
//     })
// }