var express = require('express')
var router = express.Router()
const db = require('../db/index')
const uuid = require('uuid')
const { utcNow, filterTime, getPastWeek, getPastMonth } = require('../utils/common')
const { checkPermission } = require('../utils/permission')
const { toSort, toTree } = require('../utils/recursion')
const fs = require('fs').promises;
var path = require('path')

async function getFileSize(filePath) {
  let fileSize = 0;

  try {
    const files = await fs.readdir(filePath);
    for (const file of files) {
      const fileStat = await fs.stat(path.join(filePath, file));
      fileSize += Number((fileStat.size / 1024 / 1024).toFixed(2));
    }
    return fileSize
  } catch (err) {
    console.error(`错误: ${err.message}`);
    return 0
  }
}

router.get('/', async (req, res, next) => {
  const responese = (await db(
    `select
    (select count(id) from users) as usersCount,
    (select count(userId) from blog) as blogsCount,
    (select count(DISTINCT userIp) from visit_logs) as visitCount
    `
  ))?.at()
  const fileSize = await getFileSize('./uploads')
  const data = {
    usersCount: responese.usersCount || 0,
    blogsCount: responese.blogsCount || 0,
    visitCount: responese.visitCount || 0,
    fileSize: fileSize
  }
  res.status(200).send({
    msg: '获取成功',
    data: data,
    code: 200
  })
})

router.post('/visitCount', async (req, res, next) => {
  const { visitType } = req.body
  if (!visitType) {
    res.send({
      msg: '缺少查询时间类型',
      code: 400
    })
  }
  const times = visitType === 'past_week' ? getPastWeek() : getPastMonth()
  let dates = []
  for (let time of times) {
    const responese = (await db(`select count(id) as visitCount from visit_logs where visitTime between ? and ?`, [time + ' 00:00:00', time + ' 23:59:59']))?.at()
    dates.push(responese?.visitCount)
  }
  res.send({
    msg: '获取成功',
    data: {
      times: times,
      visitCounts: dates
    },
    code: 200
  })
})

module.exports = router
