const express = require('express')

const request = require('request')

const querystring = require('querystring');

const apiList = {
    getInfoClassify:{
        url:'https://dict.zhaopin.cn/dict/dictOpenService/getDict',
        dictNames:'job_type_parent',
        getQueryUrl:function(){
            return `${this.url}?dictNames=${this.dictNames}`
        }
    }
}

const getInfoClassify = ()=>{
    const queryUrl = apiList.getInfoClassify.getQueryUrl()
    return new Promise((resolve, reject) => {
        request({
            url: queryUrl,
            gzip: true,
        }, (error, response, body) => {
            if (!error && response.statusCode == 200) {
                try {
                    const jsonObj = body;
                    resolve(jsonObj)
                } catch (err) {
                    reject(err);
                }
            } else {
                reject('请求异常');
            }
        })
    })
}

module.exports = {
    getInfoClassify
}