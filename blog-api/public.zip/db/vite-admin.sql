/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50536
 Source Host           : localhost:3306
 Source Schema         : vite-admin

 Target Server Type    : MySQL
 Target Server Version : 50536
 File Encoding         : 65001

 Date: 01/09/2024 18:59:33
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for menus
-- ----------------------------
DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus`  (
  `id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `fId` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `icon` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `path` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '菜单状态正常或停用',
  `sort` int(50) NULL DEFAULT NULL,
  `menuType` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `showMenu` int(20) NULL DEFAULT NULL COMMENT '菜单显示为1隐藏为0',
  `permission` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '权限字符',
  `outChain` int(20) NULL DEFAULT NULL COMMENT '是否为外链是为1否为0',
  `cache` int(20) NULL DEFAULT NULL COMMENT '是否缓存是为1否为0',
  `query` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '携带参数',
  `createTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of menus
-- ----------------------------
INSERT INTO `menus` VALUES ('0734ea7f-c235-4702-9cb2-1f81a0d99bdb', '286b3609-13c1-427a-b8e5-d9ee18ab2e44', NULL, '导入', NULL, NULL, 'open', 9, 'button', 1, 'system:user:import', 0, 1, NULL, '2024-08-19 16:07:24');
INSERT INTO `menus` VALUES ('0972ca0c-f983-483f-98f3-7590cf7ac87b', '286b3609-13c1-427a-b8e5-d9ee18ab2e44', NULL, '修改用户状态', NULL, NULL, 'open', 3, 'button', 1, 'system:user:update:status', 0, 1, NULL, '2024-08-19 16:03:37');
INSERT INTO `menus` VALUES ('1', NULL, 'config', '系统管理', 'setting', '/setting', 'open', 66, 'directory', 1, NULL, 0, NULL, NULL, '2024-05-31 17:24:42');
INSERT INTO `menus` VALUES ('14ea58fe-45e3-4657-83e2-41b183b4b33c', 'c9ccb419-a6c3-499c-bec3-9323f93ccf7c', NULL, '删除角色', NULL, NULL, 'open', 5, 'button', 1, 'system:role:delete', 0, 1, NULL, '2024-07-30 16:43:32');
INSERT INTO `menus` VALUES ('1f9e4c53-9796-4c1d-ba0e-115fdcd99f2c', '286b3609-13c1-427a-b8e5-d9ee18ab2e44', NULL, '导出', NULL, NULL, 'open', 8, 'button', 1, 'system:user:export', 0, 1, NULL, '2024-08-19 16:06:11');
INSERT INTO `menus` VALUES ('2', '1', 'application-menu', '菜单管理', 'setting-menu', '/setting/menu', 'open', 3, 'menu', 1, 'system:menu:all', 0, 1, NULL, '2024-05-31 17:25:16');
INSERT INTO `menus` VALUES ('201b0888-bd4c-49ec-8c3b-48ddb8925e99', 'c9ccb419-a6c3-499c-bec3-9323f93ccf7c', NULL, '新增角色', NULL, NULL, 'open', 1, 'button', 1, 'system:role:add', 0, 1, NULL, '2024-07-30 16:42:12');
INSERT INTO `menus` VALUES ('286b3609-13c1-427a-b8e5-d9ee18ab2e44', '1', 'user', '用户管理', 'setting-user', '/setting/user', 'open', 1, 'menu', 1, 'system:user:list', 0, 1, NULL, '2024-06-11 13:57:26');
INSERT INTO `menus` VALUES ('294ef28e-b16a-49b3-9934-510a9054b98d', 'c9ccb419-a6c3-499c-bec3-9323f93ccf7c', NULL, '取消分配', NULL, NULL, 'open', 7, 'button', 1, 'system:role:unBind', 0, 1, NULL, '2024-07-30 16:44:27');
INSERT INTO `menus` VALUES ('2a5eb399-69c4-447c-82bd-e4ed0e84aabe', '286b3609-13c1-427a-b8e5-d9ee18ab2e44', NULL, '修改用户', NULL, NULL, 'open', 4, 'button', 1, 'system:user:update', 0, 1, NULL, '2024-08-19 16:03:55');
INSERT INTO `menus` VALUES ('3109bd84-1192-43f6-bcd0-3a663ca2e915', 'c9ccb419-a6c3-499c-bec3-9323f93ccf7c', NULL, '分配用户', NULL, NULL, 'open', 6, 'button', 1, 'system:role:bind', 0, 1, NULL, '2024-07-30 16:44:09');
INSERT INTO `menus` VALUES ('43f065cf-843f-4d57-9cf0-b2804921a503', '286b3609-13c1-427a-b8e5-d9ee18ab2e44', NULL, '取消绑定', NULL, NULL, 'open', 7, 'button', 1, 'system:user:unBind', 0, 1, NULL, '2024-08-19 16:05:36');
INSERT INTO `menus` VALUES ('446ec95a-4ed8-4297-9826-861ff95294dd', '286b3609-13c1-427a-b8e5-d9ee18ab2e44', NULL, '删除用户', NULL, NULL, 'open', 5, 'button', 1, 'system:user:delete', 0, 1, NULL, '2024-08-19 16:04:45');
INSERT INTO `menus` VALUES ('44953b56-20e8-4309-8419-f15f2da91b43', 'c9ccb419-a6c3-499c-bec3-9323f93ccf7c', NULL, '列表', NULL, NULL, 'open', 2, 'button', 1, 'system:role:list', 0, 1, NULL, '2024-08-20 17:00:27');
INSERT INTO `menus` VALUES ('4a81f7ff-cd16-4592-910d-b11a3b1fe51e', '2', NULL, '修改菜单', NULL, NULL, 'open', 2, 'button', 1, 'system:menu:update', 0, 1, NULL, '2024-07-22 18:10:46');
INSERT INTO `menus` VALUES ('579d1f65-7d89-4a91-9db8-6afab7ee1b75', '286b3609-13c1-427a-b8e5-d9ee18ab2e44', NULL, '新增用户', NULL, NULL, 'open', 2, 'button', 1, 'system:user:add', 0, 1, NULL, '2024-08-19 16:03:14');
INSERT INTO `menus` VALUES ('60701b2c-e0a3-46d9-a8c1-a69761c958ef', 'c9ccb419-a6c3-499c-bec3-9323f93ccf7c', NULL, '修改角色状态', NULL, NULL, 'open', 4, 'button', 1, 'system:role:update:status', 0, 1, NULL, '2024-07-30 16:42:43');
INSERT INTO `menus` VALUES ('6d43a1c2-e4cb-4dd1-b53a-d18e9f516551', '2', NULL, '新增菜单', NULL, NULL, 'open', 3, 'button', 1, 'system:menu:add', 0, 1, NULL, '2024-07-22 18:09:07');
INSERT INTO `menus` VALUES ('7df6a270-bd87-4c3f-aba3-0ea4c6d9569f', '286b3609-13c1-427a-b8e5-d9ee18ab2e44', NULL, '列表', NULL, NULL, 'open', 1, 'button', 1, 'system:user:list', 0, 1, NULL, '2024-08-19 16:02:53');
INSERT INTO `menus` VALUES ('b13b5a6f-8b38-4883-866f-9471f7145508', 'c9ccb419-a6c3-499c-bec3-9323f93ccf7c', NULL, '编辑角色', NULL, NULL, 'open', 3, 'button', 1, 'system:role:update', 0, 1, NULL, '2024-07-30 16:43:18');
INSERT INTO `menus` VALUES ('c9ccb419-a6c3-499c-bec3-9323f93ccf7c', '1', 'peoples', '角色管理', 'setting-role', '/setting/role', 'open', 2, 'menu', 1, 'system:role:list', 0, 1, NULL, '2024-07-16 14:05:35');
INSERT INTO `menus` VALUES ('e9b3b70e-7119-4625-bda4-d63d82a7b753', '2', NULL, '删除菜单', NULL, NULL, 'open', 4, 'button', 1, 'system:menu:delete', 0, 1, NULL, '2024-07-22 18:11:08');
INSERT INTO `menus` VALUES ('eab016ce-f08f-46aa-90ba-1d6d24e10cd2', '1', 'aiming', '1', '1', NULL, 'disable', 989, 'directory', 1, NULL, 0, 1, NULL, '2024-08-20 02:24:59');
INSERT INTO `menus` VALUES ('f2ec8ae5-ba66-4ac2-bc9e-e35ab3031863', '2', NULL, '列表', NULL, NULL, 'open', 1, 'button', 1, 'system:menu:all', 0, 1, NULL, '2024-08-19 16:01:29');
INSERT INTO `menus` VALUES ('f94f05cc-52c3-4657-90a0-4ed1295b09da', '286b3609-13c1-427a-b8e5-d9ee18ab2e44', NULL, '绑定角色', NULL, NULL, 'open', 6, 'button', 1, 'system:user:bind', 0, 1, NULL, '2024-08-19 16:05:11');

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `role` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `roleName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `permission` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `sort` int(100) NULL DEFAULT NULL,
  `status` int(20) NULL DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `selectIds` varchar(999) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `createTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES ('001', 'admin', '超级管理员', '*:*:*', 1, 1, NULL, '*:*:*', '2024-07-11 19:29:28');
INSERT INTO `role` VALUES ('2', 'test', '测试权限', 'system:user:import,system:user:update:status,system:role:delete,system:user:export,system:role:add,system:user:list,system:role:unBind,system:user:update,system:role:bind,system:user:unBind,system:user:delete,system:role:list,system:user:add,system:role:update:status,system:user:list,system:role:update,system:role:list,system:user:bind', 2, 1, '测试角色', '286b3609-13c1-427a-b8e5-d9ee18ab2e44,7df6a270-bd87-4c3f-aba3-0ea4c6d9569f,579d1f65-7d89-4a91-9db8-6afab7ee1b75,0972ca0c-f983-483f-98f3-7590cf7ac87b,2a5eb399-69c4-447c-82bd-e4ed0e84aabe,446ec95a-4ed8-4297-9826-861ff95294dd,f94f05cc-52c3-4657-90a0-4ed1295b09da,43f065cf-843f-4d57-9cf0-b2804921a503,1f9e4c53-9796-4c1d-ba0e-115fdcd99f2c,0734ea7f-c235-4702-9cb2-1f81a0d99bdb,c9ccb419-a6c3-499c-bec3-9323f93ccf7c,201b0888-bd4c-49ec-8c3b-48ddb8925e99,44953b56-20e8-4309-8419-f15f2da91b43,b13b5a6f-8b38-4883-866f-9471f7145508,60701b2c-e0a3-46d9-a8c1-a69761c958ef,14ea58fe-45e3-4657-83e2-41b183b4b33c,3109bd84-1192-43f6-bcd0-3a663ca2e915,294ef28e-b16a-49b3-9934-510a9054b98d', '2024-07-30 16:39:52');

-- ----------------------------
-- Table structure for user_of_role
-- ----------------------------
DROP TABLE IF EXISTS `user_of_role`;
CREATE TABLE `user_of_role`  (
  `id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `userId` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `roleId` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `createTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `userId`(`userId`) USING BTREE,
  INDEX `roleId`(`roleId`) USING BTREE,
  CONSTRAINT `user_of_role_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `user_of_role_ibfk_2` FOREIGN KEY (`roleId`) REFERENCES `role` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of user_of_role
-- ----------------------------
INSERT INTO `user_of_role` VALUES ('06379a3c-76e7-4f4f-b26b-05d50809a192', '2', '2', '2024-08-06 17:55:14');
INSERT INTO `user_of_role` VALUES ('1', '1', '001', '2024-07-22 12:43:44');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `userName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `icon` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `nickName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'woman 为女 man为男 unknow为未知',
  `status` int(20) NULL DEFAULT NULL COMMENT '用户能否使用',
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `createTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('1', 'admin', '0192023a7bbd73250516f069df18b500', '99999999999', NULL, 'uploads\\å±å¹æªå¾ 2024-07-02 165800 - å¯æ¬.png', '彭于晏', 'unknown', 1, NULL, '2024-06-12 15:12:06');
INSERT INTO `users` VALUES ('2', 'test', 'e10adc3949ba59abbe56e057f20f883e', '18674152184', NULL, 'https://img0.baidu.com/it/u=365878481,4199784825&fm=253&app=120&size=w931&n=0&f=JPEG&fmt=auto?sec=1718470800&t=7a0922588019d3d8db1084a3e3859c1a', '吴彦祖', 'man', 1, '我是测试', '2024-07-24 17:01:39');
INSERT INTO `users` VALUES ('3', 'eCtIJis', 'e10adc3949ba59abbe56e057f20f883e', '24315794347', NULL, 'https://img0.baidu.com/it/u=365878481,4199784825&fm=253&app=120&size=w931&n=0&f=JPEG&fmt=auto?sec=1718470800&t=7a0922588019d3d8db1084a3e3859c1a', 'eCtIJis', 'unknown', 1, NULL, '2024-08-09 20:38:11');
INSERT INTO `users` VALUES ('33', 'MhmKSWL1', 'e10adc3949ba59abbe56e057f20f883e', '64218931606', NULL, 'https://img0.baidu.com/it/u=365878481,4199784825&fm=253&app=120&size=w931&n=0&f=JPEG&fmt=auto?sec=1718470800&t=7a0922588019d3d8db1084a3e3859c1a', 'MhmKSWL1', 'unknown', 1, NULL, '2024-08-21 18:37:13');
INSERT INTO `users` VALUES ('35', 'MhmKSWL2', 'f1887d3f9e6ee7a32fe5e76f4ab80d63', '64208931607', NULL, 'https://img0.baidu.com/it/u=365878481,4199784825&fm=253&app=120&size=w931&n=0&f=JPEG&fmt=auto?sec=1718470800&t=7a0922588019d3d8db1084a3e3859c1a', 'MhmKSWL2', 'unknown', 1, NULL, '2024-08-21 18:55:35');

SET FOREIGN_KEY_CHECKS = 1;
