const converType = (obj) => {
  
}

module.exports = {
  converType
}